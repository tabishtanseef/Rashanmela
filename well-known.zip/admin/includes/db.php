<?php

$conn=mysqli_connect("localhost","prashant","prashant@123","rashanmela");

?>