<?php
echo phpinfo();

?>