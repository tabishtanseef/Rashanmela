<nav id="sidebar">
	<div class="sidebar-header">
		<center><img src="img/sales.png" style="width:80%; padding:10px;"></center>
	</div>

	<ul class="list-unstyled components">
		<li>
			<a href="insert.php">Add Product</a>
		</li>
		<li>
			<a href="update.php">Update Product</a>
		</li>
		<li>
			<a href="stock.php">Stock Available</a>
		</li>
		<li>
			<a href="pending_orders.php">Pending Orders</a>
		</li>
		<li>
			<a href="p_order.php">All Pending Orders</a>
		</li>
		<li>
			<a href="completed_orders.php">Completed Orders</a>
		</li>
		<li>
			<a href="profile.php">Profile</a>
		</li>
		<li>
			<a href="logout.php">Logout</a>
		</li>
	</ul>

	<ul class="list-unstyled CTAs">
		<a id="date_time" class="pull-right"></a>
			<script type="text/javascript">window.onload = date_time('date_time');</script> 
	</ul>
</nav>
