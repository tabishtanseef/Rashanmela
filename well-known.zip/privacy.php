<!DOCTYPE HTML>
<html>
    <head>
    </head>
<body>
    <h1>Privacy Policy</h1>
    <h2>Personal Information</h2>
    <p>Prashant Sarkar is the owner of the brand rashanmela.com and the website rashanmela.com (”The Site”) from Supermarket Grocery Supplies. We respects your privacy. This Privacy Policy provides succinctly the manner your data is collected and used by us on the Site. As a visitor to the Site/ Customer you are advised to please read the Privacy Policy carefully. By accessing the services provided by the Site you agree to the collection and use of your data by us in the manner provided in this Privacy Policy.</p>
    <h2>What information is, or may be, collected form you?</h2>
    <p>As part of the registration process on the Site, we may collect the following personally identifiable information about you: Name including first and last name, alternate email address, mobile phone number and contact details, Postal code, Demographic profile (like address) and information about the pages on the site you visit/access, the links you click on the site, the number of times you access the page and any such browsing information.
    </p>
    <h2>With whom your information will be shared</h2>
    <p>Nobody Except our own website owner.</p>
    <h2>How can you correct inaccuracies in the information ?</h2>
    <p>You can change it by contacting us at contact@rashanmela.com</p>
    <h2></h2>
    <p></p>
</body>
</html>